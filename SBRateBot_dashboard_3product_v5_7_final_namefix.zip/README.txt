﻿SBRateBot Dashboard v5.7 FINAL NAME FIX

v5.6 기준 추가 수정
- ISA/IRP 은행명 화면 표기 통일
- 원본 API/JSON bank 값은 유지
- 화면 표시에서만 '저축은행' 제거
  예:
  우리금융저축은행 -> 우리금융
  OK저축은행 -> OK
  KB저축은행 -> KB
  신한저축은행 -> 신한
  하나저축은행 -> 하나
  애큐온저축은행 -> 애큐온

적용 범위
- ISA/IRP TOP10
- 최근 공시 TOP5
- 우리금융比 상위 TOP5
- AI 분석센터 시장/금융지주/변동
- 전체 수집기관 목록
- 전체상품조회
- 임원보고서/AI 요약

기존 유지
- AI센터 패널 높이 수정
- 우리금융 파란 rounded 강조
- 퇴직연금(IRP) 표기 / IRP 기준
- ISA/IRP 전용 AI
