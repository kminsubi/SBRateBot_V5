/**
 * SBRateBot V5 Executive Dashboard JS
 * Part 1/3
 *
 * KPI + Woori Market Position
 */



/* ==========================================================
   GLOBAL DASHBOARD DATA
========================================================== */

let dashboardKPIData = {};

let wooriMarketData = {};

window.sbLastAIQuestion = window.sbLastAIQuestion || "";
window.sbLastAIAnswer = window.sbLastAIAnswer || "";



console.log(
    "🔥 DASHBOARD JS LOADED"
);



document.addEventListener(
    "DOMContentLoaded",
    () => {


        console.log(
            "🔥 DOM CONTENT LOADED"
        );


        initDashboard();


    }
);



/* ==========================================================
   DASHBOARD INITIALIZE
========================================================== */


function initDashboard() {


    console.log(
        "🔥 SBRateBot V5 Dashboard START"
    );



    /*
        KPI DATA
    */

    fetchKPI();




    /*
        WOORI MARKET POSITION
    */

    fetchWooriData();




    /*
        HERO SECTION
    */

    loadHero();




    /*
        AI SUMMARY
    */

    fetchAISummary();


    /*
        WIBEE AI BRIEFING
    */

    fetchWibeeBriefing();


    /*
        MARKET TOP10
    */

    fetchRatesData();


    /*
        RATE CHANGE TOP5
    */

    fetchFinancialData();


    /* AI ANALYSIS CENTER */
    initAIAnalysisCenter();


    /*
        UI EVENT BINDING
    */

    setupEventListeners();


}


/* ==========================================================
   Common API Fetch
========================================================== */

async function apiFetch(url) {

    try {

        const response = await fetch(url);

        if (!response.ok) {
            throw new Error(
                `API Error : ${response.status}`
            );
        }

        return await response.json();


    } catch(error) {

        console.error(
            "API Fetch Error:",
            url,
            error
        );

        return null;
    }
}



/* ==========================================================
   KPI SECTION
   /api/kpi

   V5 Executive Dashboard KPI Rendering
========================================================== */


async function fetchKPI() {


    const data =
        await apiFetch(
            "/api/kpi"
        );


    if(!data){

        return;

    }


    console.log(
        "KPI DATA",
        data
    );


    renderKPI(
        data
    );


}

/* ==========================================================
   AI MARKET SUMMARY
   /api/ai

   V5 Executive Dashboard
   AI 시장분석 현황
========================================================== */


async function fetchAISummary(){


    const [data, kpiData, freshWooriData] = await Promise.all([
        apiFetch("/api/ai"),
        apiFetch("/api/kpi"),
        apiFetch("/api/woori")
    ]);

    if(!data){
        return;
    }

    const marketKpi = kpiData || {};
    const marketWoori = freshWooriData || wooriPositionData || {};



    console.log(
        "AI SUMMARY DATA",
        data
    );



    const target =
        document.getElementById(
            "executive-summary-mini"
        );



    if(!target){

        return;

    }



    if(

        !Array.isArray(
            data.summary
        )

    ){

        target.innerHTML =
            "시장 데이터를 분석하는 중입니다.";

        return;

    }



    const summary =
        data.summary;



    /*
        AI 의견
        summary 마지막 2개 문장 사용
    */


        const aiOpinion =

        summary
            .slice(6)
            .join("<br>")
            .replace(
                /은행별 금리 경쟁 차이가 큰 시장으로|평균금리는 3% 이상으로/g,
                ""
            )
            .trim();



/* ==========================================================
   AI DETAIL MODAL CONTENT (COMPACT EXECUTIVE STYLE)
========================================================== */


const detailContent = `


<div class="space-y-2">



<!-- 시장 흐름 분석 -->

<div
class="
bg-blue-50
border
border-blue-100
rounded-lg
px-3
py-2
"
>


<div
class="
font-bold
text-blue-700
text-xs
mb-1
"
>
📈 시장 흐름 분석
</div>


<div
class="
text-gray-600
leading-5
"
>

${

    aiOpinion

    ||

    "시장 분석 데이터가 없습니다."

}

</div>


</div>






        <!-- 시장 현황 -->

        <div
        class="border border-gray-100 rounded-xl p-3"
        >


            <div
            class="font-bold text-gray-800 mb-3 text-sm"
            >

                📊 시장 현황

            </div>



            <div
            class="grid grid-cols-5 gap-2 text-center"
            >



                <div
                class="bg-gray-50 rounded-lg p-2"
                >

                    <div
                    class="text-[10px] text-gray-400"
                    >
                        상품수
                    </div>

                    <div
                    class="text-sm font-bold text-gray-800"
                    >
                        ${Number(marketKpi.product_count || 0).toLocaleString()}개
                    </div>

                </div>





                <div
                class="bg-gray-50 rounded-lg p-2"
                >

                    <div
                    class="text-[10px] text-gray-400"
                    >
                        평균금리
                    </div>

                    <div
                    class="text-sm font-bold text-blue-700"
                    >
                        ${Number(marketKpi.average_rate || 0).toFixed(2)}%
                    </div>

                </div>





                <div
                class="bg-gray-50 rounded-lg p-2"
                >

                    <div
                    class="text-[10px] text-gray-400"
                    >
                        최고금리
                    </div>

                    <div
                    class="text-sm font-bold text-blue-700"
                    >
                        ${Number(marketKpi.max_rate || 0).toFixed(2)}%
                    </div>

                    <div
                    class="text-[9px] text-gray-400"
                    >
                        조은
                    </div>

                </div>





                <div
                class="bg-gray-50 rounded-lg p-2"
                >

                    <div
                    class="text-[10px] text-gray-400"
                    >
                        최저금리
                    </div>

                    <div
                    class="text-sm font-bold text-gray-700"
                    >
                        ${Number(marketKpi.min_rate || 0).toFixed(2)}%
                    </div>

                    <div
                    class="text-[9px] text-gray-400"
                    >
                        조은
                    </div>

                </div>





                <div
                class="bg-gray-50 rounded-lg p-2"
                >

                    <div
                    class="text-[10px] text-gray-400"
                    >
                        금리 스프레드
                    </div>

                    <div
                    class="text-sm font-bold text-orange-600"
                    >
                        ${(Number(marketKpi.max_rate || 0) - Number(marketKpi.min_rate || 0)).toFixed(2)}%p
                    </div>

                </div>



            </div>


        </div>




<!-- 우리금융 경쟁력 -->

<div
class="
bg-blue-50
border
border-blue-100
rounded-lg
px-3
py-2
"
>


<div
class="
font-bold
text-blue-700
text-xs
mb-2
"
>
🏦 우리금융 경쟁력 분석
</div>



<div
class="
grid
grid-cols-3
gap-2
text-center
"
>


<!-- 시장순위 -->

<div
class="
bg-white
rounded-lg
py-2
"
>

<div
class="text-[10px] text-gray-400"
>
시장순위
</div>


<div
class="
font-bold
text-blue-700
text-sm
"
>
${
marketWoori.market_rank
?
marketWoori.market_rank + "위"
:
"-"
}
</div>


</div>






<!-- 현재금리 -->

<div
class="
bg-white
rounded-lg
py-2
"
>

<div
class="text-[10px] text-gray-400"
>
현재금리
</div>


<div
class="
font-bold
text-gray-800
text-sm
"
>
${
marketWoori.rate
?
Number(
    marketWoori.rate
)
.toFixed(2)
+
"%"
:
"-"
}
</div>


</div>







<!-- 평균금리 대비 -->

<div
class="
bg-white
rounded-lg
py-2
"
>

<div
class="text-[10px] text-gray-400"
>
평균금리 대비
</div>


<div
class="
font-bold
text-sm
"
>


${

Number(
    marketWoori.average_gap || 0
)
> 0

?

`
<span class="text-blue-600">
+${Number(
    marketWoori.average_gap
)
.toFixed(2)}%p
</span>
`

:

Number(
    marketWoori.average_gap || 0
)
< 0

?

`
<span class="text-red-600">
▲${Math.abs(
Number(
    marketWoori.average_gap
)
)
.toFixed(2)}%p
</span>
`

:

`
<span class="text-gray-800">
0.00%p
</span>
`

}


</div>


</div>




</div>


</div>








<!-- 체크포인트 -->

<div
class="
bg-yellow-50
border
border-yellow-100
rounded-lg
px-3
py-2
"
>


<div
class="
font-bold
text-yellow-700
text-xs
mb-1
"
>
⚠️ 주요 체크포인트
</div>


<div
class="
text-gray-600
leading-5
"
>

• 경쟁사 최고금리 변화 모니터링

<br>

• 금리 상승 기관 발생 여부 확인

<br>

• 시장 평균 대비 경쟁력 점검

</div>


</div>








<!-- AI 대응 전략 -->

<div
class="
bg-gray-50
border
border-gray-100
rounded-lg
px-3
py-2
"
>


<div
class="
font-bold
text-gray-800
text-xs
mb-1
"
>
🎯 AI 대응 전략
</div>


<div
class="
text-gray-600
leading-5
"
>

• 금리 경쟁력 유지 및 시장 변화 대응

<br>

• 경쟁사 금리 조정 시 즉시 검토

<br>

• 신규 상품 출시 가능성 점검

</div>


</div>








<!-- AI 종합 판단 -->

<div
class="
bg-amber-50
border
border-amber-100
rounded-lg
px-3
py-2
"
>


<div
class="
font-bold
text-amber-800
text-xs
mb-1
"
>
🤖 AI 종합 판단
</div>


<div
class="
text-gray-700
leading-5
"
>

우리금융은 시장 내 안정적인 경쟁력을 유지하고 있습니다.

<br>

경쟁사 금리 조정 및 신규 상품 출시 여부를 지속적으로 모니터링할 필요가 있습니다.

</div>


</div>



</div>


`;



    /* ==========================================================
       모달 내용 갱신
    ========================================================== */

    const modal =

        document.getElementById(
            "market-detail-content"
        );


    if (modal) {

        modal.innerHTML = detailContent;

    }



        /*
        시장 데이터
    */


    const marketData = `


        <div class="text-xs text-gray-700 leading-5">


            <div class="mb-1 text-xs font-bold text-gray-800">

                📊 시장 현황

            </div>




            <div class="flex">


                <div class="flex-1">

                    ${summary[1] || ""}

                </div>



                <div class="flex-1">

                    ${summary[2] || ""}

                </div>



                <div class="flex-1">

                    ${summary[5] || ""}

                </div>


            </div>





            <div class="flex items-center mt-1">


                <div class="flex-1">

                    ${summary[3] || ""}

                </div>



                <div class="flex-1">

                    ${summary[4] || ""}

                </div>



                <div class="flex-1 text-right">


                    <button

                        id="market-detail-btn"

                        class="text-xs text-blue-600 font-semibold hover:underline"

                    >

                        📊 AI 상세분석 보기 >

                    </button>


                </div>


            </div>



        </div>


    `;



    /*
        최종 출력
    */


    target.innerHTML = `


        <div class="mb-2">


            <div class="text-xs font-bold text-gray-800 mb-1">

                💡 AI 의견

            </div>



            <div class="text-xs text-gray-700 leading-5">


                ${

                    aiOpinion

                    ||

                    "시장 금리 흐름을 분석 중입니다."

                }


            </div>


        </div>





        <div class="border-t pt-2">


            ${marketData}


        </div>



    `;



}



function renderKPI(data){

    dashboardKPIData = data;



    /* ======================================================
       KPI DOM
    ====================================================== */


    const highestGap =
        document.getElementById(
            "kpi-highest-gap"
        );


    const lowestGap =
        document.getElementById(
            "kpi-lowest-gap"
        );


    const averageRate =
        document.getElementById(
            "kpi-average-rate"
        );


    const averageGap =
        document.getElementById(
            "kpi-average-gap"
        );


    const productCount =
        document.getElementById(
            "kpi-product-count"
        );


    const changeCount =
        document.getElementById(
            "kpi-change-count"
        );





    /* ======================================================
       최고금리 比
    ====================================================== */


    if(highestGap){


        const value =
            Number(
                data.highest_gap || 0
            );


        highestGap.innerHTML =
            value < 0
            ?
            `
            <span class="text-red-600">
            ▲${Math.abs(value).toFixed(2)}%p
            </span>
            `
            :
            `
            <span class="text-blue-600">
            +${value.toFixed(2)}%p
            </span>
            `;


    }






    /* ======================================================
       최저금리 比
    ====================================================== */


    if(lowestGap){


        const value =
            Number(
                data.lowest_gap || 0
            );


        lowestGap.innerHTML =
            value < 0
            ?
            `
            <span class="text-red-600">
            ▲${Math.abs(value).toFixed(2)}%p
            </span>
            `
            :
            `
            <span class="text-blue-600">
            +${value.toFixed(2)}%p
            </span>
            `;


    }






    /* ======================================================
       평균금리
    ====================================================== */


    if(averageRate){


        averageRate.innerHTML =
            data.average_rate !== undefined
            ?
            `${Number(data.average_rate).toFixed(2)}%`
            :
            "-";


    }






    /* ======================================================
       평균금리 比
    ====================================================== */


    if(averageGap){


        const value =
            Number(
                data.average_gap || 0
            );


        averageGap.innerHTML =
            value < 0
            ?
            `
            <span class="text-red-600">
            ▲${Math.abs(value).toFixed(2)}%p
            </span>
            `
            :
            value > 0
            ?
            `
            <span class="text-blue-600">
            +${value.toFixed(2)}%p
            </span>
            `
            :
            `
            <span class="text-gray-800">
            0.00%p
            </span>
            `;


    }






    /* ======================================================
       상품수
    ====================================================== */


    if(productCount){


        productCount.innerHTML =
            data.product_count !== undefined
            ?
            `${Number(data.product_count).toLocaleString()}개`
            :
            "-";


    }






    /* ======================================================
       금리변동수
    ====================================================== */


    if(changeCount){


        changeCount.innerHTML =
            data.change_count !== undefined
            ?
            `${Number(data.change_count)}건`
            :
            "0건";


    }






    updateTime(
        data.last_updated
    );


}







/* ==========================================================
   LAST UPDATED
========================================================== */


function updateTime(time){


    const target =
        document.getElementById(
            "last-updated"
        );



    if(!target){

        return;

    }





    if(time){


        target.innerHTML =
        `
        <i class="fa-regular fa-clock"></i>
        기준일시 : ${time}
        `;


    }


    else{


        const now =
            new Date()
            .toLocaleString(
                "ko-KR"
            );


        target.innerHTML =
        `
        <i class="fa-regular fa-clock"></i>
        ${now}
        `;


    }


}




/* ==========================================================
   HEADER LIVE TIME + DATA UPDATE TIME
========================================================== */

function formatKoreanCurrentDateTime(dateValue){
    const d = dateValue instanceof Date ? dateValue : new Date(dateValue);

    if(Number.isNaN(d.getTime())){
        return "-";
    }

    const days = ["일","월","화","수","목","금","토"];
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth()+1).padStart(2,"0");
    const dd = String(d.getDate()).padStart(2,"0");
    const hh = String(d.getHours()).padStart(2,"0");
    const mi = String(d.getMinutes()).padStart(2,"0");
    const ss = String(d.getSeconds()).padStart(2,"0");

    return `${yyyy}-${mm}-${dd} (${days[d.getDay()]}) ${hh}:${mi}:${ss}`;
}

function extractTimeOnly(value){
    if(!value){
        return "-";
    }

    const text = String(value).trim();

    const match = text.match(/(\d{1,2}):(\d{2})(?::(\d{2}))?/);
    if(match){
        return `${String(match[1]).padStart(2,"0")}:${match[2]}`;
    }

    return text;
}

function startHeaderClock(){
    const target = document.getElementById("header-current-datetime");
    if(!target){
        return;
    }

    const render = () => {
        target.textContent = formatKoreanCurrentDateTime(new Date());
    };

    render();
    window.setInterval(render, 1000);
}

function parseDashboardDateTime(value){
    if(!value){
        return null;
    }

    const raw = String(value).trim();

    const match = raw.match(
        /(\d{4})[-./](\d{1,2})[-./](\d{1,2})[^\d]+(\d{1,2}):(\d{2})(?::(\d{2}))?/
    );

    if(match){
        return new Date(
            Number(match[1]),
            Number(match[2]) - 1,
            Number(match[3]),
            Number(match[4]),
            Number(match[5]),
            Number(match[6] || 0)
        );
    }

    const parsed = new Date(raw);

    return Number.isNaN(parsed.getTime())
        ? null
        : parsed;
}

function formatDataBasis(value){
    const parsed = parseDashboardDateTime(value);

    if(parsed){
        const yyyy = parsed.getFullYear();
        const mm = String(parsed.getMonth()+1).padStart(2,"0");
        const dd = String(parsed.getDate()).padStart(2,"0");
        const hh = String(parsed.getHours()).padStart(2,"0");
        const mi = String(parsed.getMinutes()).padStart(2,"0");

        return `${yyyy}-${mm}-${dd} ${hh}:${mi}`;
    }

    return value
        ? String(value)
        : "-";
}

function renderDataFreshness(value){
    const badge = document.getElementById("header-data-status");

    if(!badge){
        return;
    }

    badge.className =
        "px-2 py-0.5 rounded-full text-[10px] font-semibold whitespace-nowrap";

    const parsed = parseDashboardDateTime(value);

    if(!parsed){
        badge.textContent = "기준시각 확인";
        badge.classList.add(
            "bg-gray-100",
            "text-gray-500",
            "border",
            "border-gray-200"
        );
        return;
    }

    const ageHours =
        (Date.now() - parsed.getTime())
        / (1000 * 60 * 60);

    if(ageHours >= 24){
        badge.textContent = "갱신 지연";
        badge.classList.add(
            "bg-orange-50",
            "text-orange-700",
            "border",
            "border-orange-100"
        );
    }
    else{
        badge.textContent = "최신";
        badge.classList.add(
            "bg-emerald-50",
            "text-emerald-700",
            "border",
            "border-emerald-100"
        );
    }
}

async function refreshHeaderDataUpdateTime(){
    const target = document.getElementById("header-data-update-time");

    if(!target){
        return;
    }

    const kpi = await apiFetch("/api/kpi");

    const value =
        kpi?.last_updated ??
        kpi?.last_update ??
        kpi?.updated_at ??
        null;

    window.sbDataBasisValue = value;

    target.textContent = formatDataBasis(value);
    target.title = value
        ? `데이터 기준일시: ${value}`
        : "데이터 기준일시 정보 없음";

    renderDataFreshness(value);

    const reportBasis =
        document.getElementById(
            "ai-report-data-basis"
        );

    if(reportBasis){
        reportBasis.textContent =
            `데이터 기준 ${formatDataBasis(value)}`;
    }
}

function setupHeaderRefresh(){
    const btn = document.getElementById("header-refresh-btn");
    if(!btn){
        return;
    }

    btn.addEventListener("click", async () => {
        btn.disabled = true;

        try{
            await Promise.all([
                refreshHeaderDataUpdateTime(),
                typeof fetchKPI === "function" ? fetchKPI() : Promise.resolve(),
                typeof fetchRatesData === "function" ? fetchRatesData() : Promise.resolve(),
                typeof fetchFinancialData === "function" ? fetchFinancialData() : Promise.resolve(),
                typeof fetchWibeeBriefing === "function" ? fetchWibeeBriefing() : Promise.resolve()
            ]);

            if(typeof renderAIAnalysisCenter === "function"){
                await renderAIAnalysisCenter(aiCenterActiveTab || "market");
            }
        }
        finally{
            btn.disabled = false;
        }
    });
}

/* ==========================================================
   WOORI MARKET POSITION
   /api/woori
========================================================== */


let wooriPositionData = {};



async function fetchWooriData(){


    const data =
        await apiFetch(
            "/api/woori"
        );


    if(!data){

        console.log(
            "WOORI DATA EMPTY"
        );

        return;

    }



    console.log(
        "🔥 WOORI API",
        data
    );



    wooriPositionData = data;



    renderWooriPosition(
        data
    );


}





function renderWooriPosition(data){

    console.log(
        "🔥 RENDER WOORI",
        data
    );


    const rank =
        document.getElementById(
            "woori-rank"
        );


    const rate =
        document.getElementById(
            "woori-rate"
        );


    const avgGap =
        document.getElementById(
            "woori-gap-average"
        );



    /*
        시장순위
    */

    if(rank){

        rank.innerHTML =
            data.market_rank
            ?
            `${data.market_rank}위`
            :
            "-";

    }



    /*
        현재금리
    */

    if(rate){

        rate.innerHTML =
            data.rate !== undefined
            ?
            `${Number(data.rate).toFixed(2)}%`
            :
            "-";

    }



    /*
        시장평균 대비
    */

    if(avgGap){


        const value =
            Number(
                data.average_gap ?? 0
            );


        if(
            value > 0
        ){

            avgGap.innerHTML =
            `
            <span class="text-blue-600 font-bold">
            +${value.toFixed(2)}%p
            </span>
            `;


        }
        else if(
            value < 0
        ){

            avgGap.innerHTML =
            `
            <span class="text-red-600 font-bold">
            ▲${Math.abs(value).toFixed(2)}%p
            </span>
            `;


        }
        else{


            avgGap.innerHTML =
            `
            <span class="text-gray-500">
            -
            </span>
            `;


        }


    }



}

/* ==========================================================
   WIBEE AI BRIEFING
   /api/kpi + /api/woori
========================================================== */

async function fetchWibeeBriefing(){

    const [kpi, woori, changes] = await Promise.all([
        apiFetch("/api/kpi"),
        apiFetch("/api/woori"),
        apiFetch("/api/rate-changes")
    ]);

    if(!kpi || !woori){
        return;
    }

    renderWibeeBriefing(kpi, woori, changes || {});
}


function renderWibeeBriefing(kpi, woori, changes = {}){

    const status = document.getElementById("wibee-market-status");
    const judgementEl = document.getElementById("wibee-judgement");
    const riseEl = document.getElementById("wibee-rise-count");
    const fallEl = document.getElementById("wibee-fall-count");
    const changeEl = document.getElementById("wibee-change-count");
    const wooriRateEl = document.getElementById("wibee-woori-rate");
    const rankEl = document.getElementById("wibee-rank");
    const bestRateEl = document.getElementById("wibee-best-rate");
    const averageRateEl = document.getElementById("wibee-average-rate");

    const gap = Number(woori.average_gap ?? kpi.average_gap ?? 0);
    const changeCount = Number(
        changes.change_count ??
        changes.total_change_count ??
        kpi.change_count ??
        0
    );
    const riseCount = Number(
        changes.up_count ??
        changes.rise_count ??
        (Array.isArray(changes.up_all) ? changes.up_all.length : 0)
    );
    const fallCount = Number(
        changes.down_count ??
        changes.fall_count ??
        (Array.isArray(changes.down_all) ? changes.down_all.length : 0)
    );

    let marketStatus = "안정";
    let dotClass = "bg-emerald-500";
    let textClass = "text-emerald-600";

    if(changeCount >= 120){
        marketStatus = "변동 확대";
        dotClass = "bg-orange-500";
        textClass = "text-orange-600";
    }
    else if(changeCount >= 80){
        marketStatus = "변동 관찰";
        dotClass = "bg-amber-400";
        textClass = "text-amber-600";
    }

    if(status){
        status.className = `inline-flex items-center gap-1 ${textClass}`;
        status.innerHTML = `<span class="w-2 h-2 rounded-full ${dotClass}"></span>${marketStatus}`;
    }

    if(riseEl){ riseEl.textContent = Number.isFinite(riseCount) ? riseCount : 0; }
    if(fallEl){ fallEl.textContent = Number.isFinite(fallCount) ? fallCount : 0; }
    if(changeEl){ changeEl.textContent = Number.isFinite(changeCount) ? changeCount : 0; }

    const wooriRate = Number(woori.rate ?? woori.best_rate ?? 0);
    const bestRate = Number(kpi.max_rate ?? kpi.highest_rate ?? 0);
    const averageRate = Number(kpi.average_rate ?? kpi.avg_rate ?? 0);
    const rank = woori.market_rank ?? woori.rank ?? "-";
    const total = woori.market_total ?? woori.total ?? "-";

    if(wooriRateEl){
        wooriRateEl.textContent = Number.isFinite(wooriRate) && wooriRate > 0 ? `${wooriRate.toFixed(2)}%` : "-";
    }
    if(bestRateEl){
        bestRateEl.textContent = Number.isFinite(bestRate) && bestRate > 0 ? `${bestRate.toFixed(2)}%` : "-";
    }
    if(averageRateEl){
        averageRateEl.textContent = Number.isFinite(averageRate) && averageRate > 0 ? `${averageRate.toFixed(2)}%` : "-";
    }
    if(rankEl){
        rankEl.textContent = rank !== "-" ? `${rank}위 / ${total}` : "-";
    }

    if(judgementEl){
        let judgement = "시장 평균 수준의 금리 경쟁이 이어지고 있습니다.";
        if(gap < -0.20){
            judgement = "우리금융은 시장평균을 하회해 상위권과의 금리 격차 점검이 필요합니다.";
        }
        else if(gap < 0){
            judgement = "우리금융은 시장평균을 소폭 하회하며 최고금리 중심의 경쟁을 모니터링할 필요가 있습니다.";
        }
        else if(gap > 0.20){
            judgement = "우리금융은 시장평균을 뚜렷하게 상회하며 높은 금리 경쟁력을 유지하고 있습니다.";
        }
        else if(gap > 0){
            judgement = "우리금융은 시장평균을 소폭 상회하며 안정적인 금리 경쟁력을 유지하고 있습니다.";
        }
        judgementEl.textContent = judgement;
    }
}


/* ==========================================================
   TOP 10 RATE RANKING
   /api/rates
========================================================== */

async function fetchRatesData() {

    const select =
        document.getElementById(
            "top10-category-select"
        );

    let category = "ALL";

    if (select) {

        category =
            select.value;

    }

    const data =
        await apiFetch(
            `/api/rates?category=${category}`
        );

    if (!data) {
        return;
    }

    renderTop10(
        data.top10 || data
    );

}

function renderTop10(items) {

    const top5Body =
        document.getElementById(
            "top5-table-body"
        );

    const top10Body =
        document.getElementById(
            "top10-table-body"
        );

    if (!top5Body || !top10Body) {
        return;
    }

    top5Body.innerHTML = "";
    top10Body.innerHTML = "";

    if (!Array.isArray(items) || items.length === 0) {

        const emptyRow = `
        <tr>
            <td colspan="4" class="text-center py-4 text-gray-400">
                데이터 없음
            </td>
        </tr>
        `;

        top5Body.innerHTML = emptyRow;
        top10Body.innerHTML = emptyRow;
        return;
    }

    items
        .slice(0, 10)
        .forEach((item, index) => {

            const tr = document.createElement("tr");

            const bank =
                item.kor_co_nm ||
                item.bank_name ||
                item.bank ||
                "-";

            const rate =
                item.intr_rate2 ??
                item.max_rate ??
                item.intr_rate ??
                item.base_rate ??
                item.rate ??
                null;

            const rawDiff =
                item.diff ??
                item.change ??
                item.change_value ??
                0;

            const diffValue = Number(rawDiff);
            let diffHtml = '<span class="text-gray-400">-</span>';

            if(!Number.isNaN(diffValue) && diffValue > 0){
                diffHtml = `<span class="text-blue-600">+${diffValue.toFixed(2)}%p</span>`;
            }
            else if(!Number.isNaN(diffValue) && diffValue < 0){
                diffHtml = `<span class="text-red-500">▲${Math.abs(diffValue).toFixed(2)}%p</span>`;
            }
            else if(typeof rawDiff === "string" && rawDiff.trim() && rawDiff !== "-"){
                diffHtml = rawDiff;
            }

            const isWoori = String(bank).includes("우리금융");

            if(isWoori){
                tr.className = "bg-blue-50/80 font-bold text-blue-700 [box-shadow:inset_0_0_0_1px_#bfdbfe]";
            }

            const rankClass = index < 3
                ? "bg-orange-100 text-orange-600"
                : isWoori
                    ? "bg-blue-600 text-white"
                    : "bg-gray-100 text-gray-600";

            tr.innerHTML = `
            <td class="py-2 text-center">
                <span class="${rankClass} w-4 h-4 rounded-full inline-flex items-center justify-center text-[10px] font-bold">
                    ${index + 1}
                </span>
            </td>
            <td class="py-2 text-center truncate px-1" title="${bank}">${bank}</td>
            <td class="py-2 text-center font-semibold ${isWoori ? "text-blue-700" : "text-blue-600"}">
                ${rate !== null && !Number.isNaN(Number(rate)) ? Number(rate).toFixed(2) + "%" : "-"}
            </td>
            <td class="py-2 text-center font-semibold whitespace-nowrap">
                ${diffHtml}
            </td>
            `;

            if (index < 5) {
                top5Body.appendChild(tr);
            }
            else {
                top10Body.appendChild(tr);
            }

        });
}



/* ==========================================================
   시장 전체 순위 MODAL
========================================================== */

async function openAllRatesModal(){

    const modal = document.getElementById("top10-all-modal");
    const tbody = document.getElementById("top10-all-table-body");

    if(!modal || !tbody){
        return;
    }

    modal.classList.remove("hidden");
    modal.classList.add("flex");

    tbody.innerHTML = `
        <tr>
            <td colspan="5" class="py-6 text-center text-gray-400">
                전체 순위를 불러오는 중입니다.
            </td>
        </tr>
    `;

    const data = await apiFetch("/api/rates?all=1");
    const items = Array.isArray(data) ? data : [];

    if(items.length === 0){
        tbody.innerHTML = `
            <tr>
                <td colspan="5" class="py-6 text-center text-gray-400">
                    순위 데이터가 없습니다.
                </td>
            </tr>
        `;
        return;
    }

    tbody.innerHTML = "";

    items.forEach((item, index) => {

        const bank = item.bank || item.bank_name || item.kor_co_nm || "-";
        const product = item.product || item.product_name || item.fin_prdt_nm || "-";
        const rate = Number(item.rate ?? item.max_rate ?? item.intr_rate2);
        const change = Number(item.change ?? item.diff ?? 0);
        const isWoori = String(bank).includes("우리금융");

        let changeHtml = '<span class="text-gray-400">-</span>';
        if(Number.isFinite(change) && change > 0){
            changeHtml = `<span class="text-blue-600">+${change.toFixed(2)}%p</span>`;
        }
        else if(Number.isFinite(change) && change < 0){
            changeHtml = `<span class="text-red-500">▲${Math.abs(change).toFixed(2)}%p</span>`;
        }

        const tr = document.createElement("tr");
        if(isWoori){
            tr.className = "bg-blue-50/80 font-bold text-blue-700 [box-shadow:inset_0_0_0_1px_#bfdbfe]";
        }

        tr.innerHTML = `
            <td class="py-2 text-center">${item.rank ?? index + 1}</td>
            <td class="py-2 text-center ${isWoori ? "font-bold text-blue-700" : "text-gray-700"}">${bank}</td>
            <td class="py-2 text-center text-gray-500 truncate" title="${product}">${product}</td>
            <td class="py-2 text-right font-semibold ${isWoori ? "text-blue-700" : "text-gray-800"}">${Number.isFinite(rate) ? rate.toFixed(2) + "%" : "-"}</td>
            <td class="py-2 text-right whitespace-nowrap">${changeHtml}</td>
        `;

        tbody.appendChild(tr);
    });
}

function closeAllRatesModal(){
    const modal = document.getElementById("top10-all-modal");
    if(!modal){
        return;
    }
    modal.classList.add("hidden");
    modal.classList.remove("flex");
}

document.addEventListener("click", function(e){
    if(e.target.closest("#top10-all-btn")){
        openAllRatesModal();
        return;
    }

    if(e.target.closest("#top10-all-close")){
        closeAllRatesModal();
        return;
    }

    const modal = document.getElementById("top10-all-modal");
    if(modal && e.target === modal){
        closeAllRatesModal();
    }
});





/* ==========================================================
   상승 / 하락 TOP5
   /api/financial
========================================================== */


async function fetchFinancialData(){

    // V6: 백엔드 전용 변동 API를 우선 사용
    const data = await apiFetch(
        "/api/rate-changes"
    );

    if(data){

        const upList = Array.isArray(data.up_top5)
            ? data.up_top5
            : [];

        const downList = Array.isArray(data.down_top5)
            ? data.down_top5
            : [];

        console.log(
            "RATE CHANGE API",
            data
        );

        renderRateChanges(
            upList,
            downList
        );

        return;
    }

    // API 실패 시 기존 /api/rates 결과를 이용한 최소 fallback
    const rates = await apiFetch(
        "/api/rates?all=1"
    );

    const items = Array.isArray(rates)
        ? rates
        : [];

    const normalized = items
        .map(item => ({
            ...item,
            change_value: Number(item.change ?? 0)
        }))
        .filter(item => Number.isFinite(item.change_value));

    const upList = normalized
        .filter(item => item.change_value > 0)
        .sort((a,b) => b.change_value - a.change_value)
        .slice(0,5);

    const downList = normalized
        .filter(item => item.change_value < 0)
        .sort((a,b) => a.change_value - b.change_value)
        .slice(0,5);

    renderRateChanges(
        upList,
        downList
    );
}

function renderRateChanges(
    upList,
    downList
){

    const up = document.getElementById("rates-up-list");
    const down = document.getElementById("rates-down-list");

    const renderRows = (target, list, direction) => {

        if(!target){
            return;
        }

        target.innerHTML = "";

        if(!Array.isArray(list) || list.length === 0){
            target.innerHTML = `
            <tr>
                <td colspan="4" class="py-4 text-center text-gray-400 font-normal">
                    ${direction === "up" ? "금리 상승 없음" : "금리 하락 없음"}
                </td>
            </tr>
            `;
            return;
        }

        list.slice(0, 5).forEach((item, index) => {

            const bank =
                item.kor_co_nm ||
                item.bank_name ||
                item.bank ||
                "-";

            const currentRateRaw =
                item.rate ??
                item.current_rate ??
                item.new_rate ??
                item.intr_rate2 ??
                item.max_rate ??
                null;

            const currentRate = Number(currentRateRaw);

            let value = Number(
                item.change_value ??
                item.change ??
                ((Number(item.new_rate) || 0) - (Number(item.old_rate) || 0))
            );

            if(Number.isNaN(value)){
                value = 0;
            }

            const absValue = Math.abs(value).toFixed(2);
            const tr = document.createElement("tr");

            const isWoori = String(bank).includes("우리금융");
            if(isWoori){
                tr.className = "bg-blue-50/80 font-bold text-blue-700 [box-shadow:inset_0_0_0_1px_#bfdbfe]";
            }

            tr.innerHTML = `
                <td class="py-2 text-center ${isWoori ? "text-blue-700" : "text-gray-500"}">${index + 1}</td>
                <td class="py-2 text-center px-1 ${isWoori ? "text-blue-700 font-bold" : "text-gray-700"} truncate" title="${bank}">${bank}</td>
                <td class="py-2 text-center text-xs font-semibold whitespace-nowrap ${isWoori ? "text-blue-700" : "text-gray-700"}">
                    ${Number.isFinite(currentRate) ? currentRate.toFixed(2) + "%" : "-"}
                </td>
                <td class="py-2 text-center text-xs font-semibold whitespace-nowrap ${isWoori ? "text-blue-700 font-bold" : (direction === "up" ? "text-blue-600" : "text-red-500")}">
                    ${direction === "up" ? "+" : "▲"}${absValue}%p
                </td>
            `;

            target.appendChild(tr);
        });
    };

    renderRows(up, upList, "up");
    renderRows(down, downList, "down");
}




/* ==========================================================
   전체 상품 조회 - V5 실제 데이터 연결
   /api/products
========================================================== */

let allProductData = [];

function productBankName(item){
    return String(item.bank ?? item.kor_co_nm ?? item.bank_name ?? "").trim();
}

function productName(item){
    return String(item.product ?? item.fin_prdt_nm ?? item.product_name ?? "").trim();
}

function productPeriod(item){
    const raw = item.period ?? item.save_trm ?? item.period_months ?? "";
    const match = String(raw).match(/\d+/);
    return match ? match[0] : String(raw || "");
}

function productRate(item){
    const raw = item.rate ?? item.intr_rate2 ?? item.max_rate ?? item.intr_rate ?? item.base_rate;
    const value = Number(raw);
    return Number.isFinite(value) ? value : null;
}

function productChange(item){
    const raw = item.change ?? item.diff ?? item.change_value;
    const value = Number(raw);
    return Number.isFinite(value) ? value : 0;
}

async function fetchAllProducts(){
    const data = await apiFetch("/api/products");
    if(!data){
        renderAllProductsTable([]);
        return;
    }

    allProductData = Array.isArray(data)
        ? data
        : (data.products || data.all_products || data.items || []);

    populateProductBankSelect(allProductData);
    applyProductFilters();
}

function populateProductBankSelect(products){
    const select = document.getElementById("product-bank-select");
    if(!select || select.dataset.loaded === "1") return;

    const banks = [...new Set(products.map(productBankName).filter(Boolean))]
        .sort((a,b) => a.localeCompare(b, "ko"));

    banks.forEach(bank => {
        const option = document.createElement("option");
        option.value = bank;
        option.textContent = bank;
        select.appendChild(option);
    });
    select.dataset.loaded = "1";
}

function applyProductFilters(){
    const bank = document.getElementById("product-bank-select")?.value?.trim() || "";
    const period = document.getElementById("product-period-select")?.value?.trim() || "";
    const sortMode = document.getElementById("product-sort-select")?.value || "rate_desc";
    const keyword = document.getElementById("product-search-input")?.value?.trim().toLowerCase() || "";

    let filtered = [...allProductData];
    if(bank) filtered = filtered.filter(item => productBankName(item) === bank);
    if(period) filtered = filtered.filter(item => productPeriod(item) === period);
    if(keyword){
        filtered = filtered.filter(item => `${productBankName(item)} ${productName(item)}`.toLowerCase().includes(keyword));
    }

    filtered.sort((a,b) => {
        if(sortMode === "rate_asc"){
            const diff =
                (productRate(a) ?? Number.MAX_VALUE)
                - (productRate(b) ?? Number.MAX_VALUE);

            return diff !== 0
                ? diff
                : productBankName(a).localeCompare(
                    productBankName(b),
                    "ko"
                );
        }

        if(sortMode === "change_desc"){
            const diff =
                Math.abs(productChange(b))
                - Math.abs(productChange(a));

            return diff !== 0
                ? diff
                : (productRate(b) ?? -1)
                    - (productRate(a) ?? -1);
        }

        if(sortMode === "bank_asc"){
            const bankDiff =
                productBankName(a).localeCompare(
                    productBankName(b),
                    "ko"
                );

            return bankDiff !== 0
                ? bankDiff
                : (productRate(b) ?? -1)
                    - (productRate(a) ?? -1);
        }

        // 기본: 금리 높은순
        // ISA/IRP 확장 시 disclosure_date 최신순 모드를
        // 이 정렬 구조에 추가할 수 있도록 분리해 둠.
        const diff =
            (productRate(b) ?? -1)
            - (productRate(a) ?? -1);

        return diff !== 0
            ? diff
            : productBankName(a).localeCompare(
                productBankName(b),
                "ko"
            );
    });
    renderAllProductsTable(filtered);
}

function renderAllProductsTable(products){
    const tbody = document.getElementById("all-products-table-body");
    const count = document.getElementById("product-result-count");
    if(count) count.textContent = `${Number(products.length).toLocaleString()}개 조회`;
    if(!tbody) return;

    tbody.innerHTML = "";
    if(!Array.isArray(products) || products.length === 0){
        tbody.innerHTML = `<tr><td colspan="6" class="py-6 text-center text-gray-400">조회 조건에 맞는 상품이 없습니다.</td></tr>`;
        return;
    }

    products.forEach((item,index) => {
        const bank = productBankName(item) || "-";
        const product = productName(item) || "-";
        const period = productPeriod(item);
        const rate = productRate(item);
        const change = productChange(item);
        const isWoori = bank.includes("우리금융");
        let changeHtml = '<span class="text-gray-400">-</span>';
        if(change > 0) changeHtml = `<span class="text-blue-600 font-semibold">+${change.toFixed(2)}%p</span>`;
        else if(change < 0) changeHtml = `<span class="text-red-500 font-semibold">▲${Math.abs(change).toFixed(2)}%p</span>`;

        const tr = document.createElement("tr");
        if(isWoori) tr.className = "bg-blue-50/70 text-blue-700 font-semibold";
        tr.innerHTML = `
            <td class="py-2 text-center text-gray-400">${index+1}</td>
            <td class="py-2 px-2 text-center truncate ${isWoori ? "text-blue-700" : "text-gray-700"}" title="${bank}">${bank}</td>
            <td class="py-2 px-2 text-left truncate ${isWoori ? "text-blue-700" : "text-gray-700"}" title="${product}">${product}</td>
            <td class="py-2 text-center text-gray-500">${period ? period + "개월" : "-"}</td>
            <td class="py-2 text-center font-bold ${isWoori ? "text-blue-700" : "text-gray-800"}">${rate !== null ? rate.toFixed(2) + "%" : "-"}</td>
            <td class="py-2 text-center whitespace-nowrap">${changeHtml}</td>`;
        tbody.appendChild(tr);
    });
}

/* ==========================================================
   Gemini AI Assistant
   /api/ai/search
========================================================== */


async function handleAISearch(event){


    if(event){

        event.preventDefault();

    }


    const input =
        document.getElementById(
            "ai-question"
        )
        ||
        document.getElementById(
            "ai-query-input"
        );


    const answerBox =
        document.getElementById(
            "ai-mini-answer"
        );


    if(!input){

        console.log(
            "AI 질문 입력창 없음"
        );

        return;

    }


    const query =
        input.value.trim();


    if(!query){

        return;

    }


    if(answerBox){

        answerBox.innerHTML =
            `
            <span class="text-gray-400">
            AI가 분석 중입니다...
            </span>
            `;

    }


    try{


        const response =
            await fetch(
                "/api/ai/search",
                {

                    method:"POST",

                    headers:{
                        "Content-Type":
                        "application/json"
                    },

                    body:
                        JSON.stringify({
                            question:query
                        })

                }
            );


        if(!response.ok){

            throw new Error(
                `AI API Error : ${response.status}`
            );

        }


        const data =
            await response.json();


        const answer =
            data.answer ||
            data.result ||
            data.message ||
            "분석 결과가 없습니다.";

        const normalizeAIAnswerHtml = (value) => {
            let text = String(value ?? "")
                .replace(/^\s*Gemini AI 답변\s*/i, "")
                .replace(/^\s*제미나이 AI 답변\s*/i, "");

            // API가 <span>, <br> 등을 엔티티로 반환한 경우 한 번 복원
            if(/&lt;\/?(?:span|br|strong|b|div|p)\b/i.test(text)){
                const textarea = document.createElement("textarea");
                textarea.innerHTML = text;
                text = textarea.value;
            }

            const template = document.createElement("template");
            text = text
                .replace(/\r\n/g, "\n")
                .replace(/\n[ \t]*\n[ \t]*\n+/g, "\n\n");

            template.innerHTML = text.replace(/\n/g, "<br>");
            template.content.querySelectorAll("script, iframe, object, embed, style").forEach(el => el.remove());
            template.content.querySelectorAll("*").forEach(el => {
                [...el.attributes].forEach(attr => {
                    if(/^on/i.test(attr.name)) el.removeAttribute(attr.name);
                    if((attr.name === "href" || attr.name === "src") && /^javascript:/i.test(attr.value)) el.removeAttribute(attr.name);
                });
            });
            return template.innerHTML;
        };

        const cleanAnswerHtml = normalizeAIAnswerHtml(answer);
        const plainHolder = document.createElement("div");
        plainHolder.innerHTML = cleanAnswerHtml;
        const cleanAnswerText = plainHolder.innerText.trim();

        window.sbLastAIQuestion = query;
        window.sbLastAIAnswerText = cleanAnswerText;

        const applyRateColors = (root) => {
            root.querySelectorAll(".rate-change.increase").forEach(el => {
                el.classList.add("text-blue-600", "font-semibold");
            });
            root.querySelectorAll(".rate-change.decrease").forEach(el => {
                el.classList.add("text-red-600", "font-semibold");
            });
            root.querySelectorAll(".rate-change:not(.increase):not(.decrease)").forEach(el => {
                el.classList.add("text-gray-500");
            });
        };

        const decoratePlainRateChanges = (root) => {
            const walker = document.createTreeWalker(
                root,
                NodeFilter.SHOW_TEXT
            );
            const nodes = [];
            while(walker.nextNode()){
                const node = walker.currentNode;
                if(node.parentElement?.closest(".rate-change")) continue;
                if(/[+▲]\s*\d+(?:\.\d+)?%p/.test(node.nodeValue || "")){
                    nodes.push(node);
                }
            }

            nodes.forEach(node => {
                const text = node.nodeValue || "";
                const frag = document.createDocumentFragment();
                let last = 0;
                const re = /([+▲])\s*(\d+(?:\.\d+)?)%p/g;
                let match;
                while((match = re.exec(text))){
                    if(match.index > last){
                        frag.appendChild(document.createTextNode(text.slice(last, match.index)));
                    }
                    const span = document.createElement("span");
                    span.className = match[1] === "+"
                        ? "rate-change increase text-blue-600 font-semibold"
                        : "rate-change decrease text-red-600 font-semibold";
                    span.textContent = `${match[1]}${match[2]}%p`;
                    frag.appendChild(span);
                    last = re.lastIndex;
                }
                if(last < text.length){
                    frag.appendChild(document.createTextNode(text.slice(last)));
                }
                node.replaceWith(frag);
            });
        };

        if(answerBox){
            // 원문의 줄바꿈은 살리되, 과도한 빈 줄만 한 칸으로 축소
            const miniTemplate = document.createElement("template");
            miniTemplate.innerHTML = cleanAnswerHtml;
            applyRateColors(miniTemplate.content);
            decoratePlainRateChanges(miniTemplate.content);

            const brs = [...miniTemplate.content.querySelectorAll("br")];
            brs.forEach((br, idx) => {
                const next = br.nextSibling;
                if(next && next.nodeName === "BR"){
                    const spacer = document.createElement("span");
                    spacer.className = "block h-1";
                    br.replaceWith(spacer);
                    next.remove();
                }
            });

            answerBox.innerHTML = miniTemplate.innerHTML;
        }

        // 상세보기에서도 증감 색상이 항상 유지되도록 저장본에도 클래스 보강
        const detailTemplate = document.createElement("template");
        detailTemplate.innerHTML = cleanAnswerHtml;
        applyRateColors(detailTemplate.content);
        decoratePlainRateChanges(detailTemplate.content);
        window.sbLastAIAnswer = detailTemplate.innerHTML;


        console.log(
            "AI SEARCH RESULT",
            data
        );


    }
    catch(error){


        console.error(
            "AI Error:",
            error
        );


        if(answerBox){

            answerBox.innerHTML =
                `
                <span class="text-red-500">
                AI 분석 요청 중 오류가 발생했습니다.
                </span>
                `;

        }


    }


}




/* ==========================================================
   Chat UI Helper
========================================================== */


function appendChatMessage(
    message,
    className
){


    const container =
        document.getElementById(
            "ai-chat-messages"
        );


    if(!container){
        return null;
    }



    const id =
        "chat-" + Date.now();



    const div =
        document.createElement(
            "div"
        );


    div.id=id;


    div.className =
        `chat-bubble ${className}`;



    div.textContent =
        message;



    container.appendChild(
        div
    );



    container.scrollTop =
        container.scrollHeight;



    return id;


}



function removeChatMessage(id){


    const target =
        document.getElementById(
            id
        );


    if(target){

        target.remove();

    }

}



/* ==========================================================
   상품 검색
========================================================== */


function setupProductSearch(){
    const input = document.getElementById("product-search-input");
    const button = document.getElementById("product-search-btn");
    const bankSelect = document.getElementById("product-bank-select");
    const periodSelect = document.getElementById("product-period-select");
    const sortSelect = document.getElementById("product-sort-select");

    if(input){
        input.addEventListener("keydown", e => {
            if(e.key === "Enter"){
                e.preventDefault();
                applyProductFilters();
            }
        });
    }
    if(button) button.addEventListener("click", applyProductFilters);
    if(bankSelect) bankSelect.addEventListener("change", applyProductFilters);
    if(periodSelect) periodSelect.addEventListener("change", applyProductFilters);
    if(sortSelect) sortSelect.addEventListener("change", applyProductFilters);
}


/* ==========================================================
   AI 분석센터 V5 - 4탭 실제 데이터 연결
========================================================== */

let aiCenterActiveTab = "market";

function aiCenterRate(value){
    const n = Number(value);
    return Number.isFinite(n) ? `${n.toFixed(2)}%` : "-";
}

function aiCenterGap(value){
    const n = Number(value);
    if(!Number.isFinite(n)) return '<span class="text-gray-500">-</span>';
    if(n > 0) return `<span class="text-blue-600 font-bold">+${n.toFixed(2)}%p</span>`;
    if(n < 0) return `<span class="text-red-600 font-bold">▲${Math.abs(n).toFixed(2)}%p</span>`;
    return '<span class="text-gray-800 font-bold">0.00%p</span>';
}

function aiCenterChange(value){
    const n = Number(value);
    if(!Number.isFinite(n)) return '<span class="text-gray-400">-</span>';
    if(n > 0) return `<span class="text-blue-600 font-semibold">+${n.toFixed(2)}%p</span>`;
    if(n < 0) return `<span class="text-red-600 font-semibold">▲${Math.abs(n).toFixed(2)}%p</span>`;
    return '<span class="text-gray-700 font-semibold">0.00%p</span>';
}


function escapeReportHtml(value){
    return String(value ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

function closeAIExecutiveReport(){
    const modal = document.getElementById("ai-report-modal");
    if(!modal){
        return;
    }

    modal.classList.add("hidden");
    modal.classList.remove("flex");
}

function buildExecutiveReportBase(data, dataBasis){
    const {kpi, woori, rates, financial, changes} = data;
    const top = rates[0] || {};
    const financialTop = financial[0] || {};
    const upCount = changes.up_count ?? (changes.up_top5 || []).length ?? 0;
    const downCount = changes.down_count ?? (changes.down_top5 || []).length ?? 0;

    return `
      <div id="executive-report-document" class="space-y-4 bg-white">
        <div class="border-b border-gray-200 pb-3">
          <div class="text-lg font-bold text-gray-900">SBRateBot Executive Intelligence Report</div>
          <div class="text-[11px] text-gray-500 mt-1">데이터 기준 ${dataBasis} · 생성 ${formatKoreanCurrentDateTime(new Date())}</div>
        </div>

        <section>
          <div class="font-bold text-blue-700 mb-2">1. 핵심 요약</div>
          <div class="grid grid-cols-4 gap-2 text-center">
            <div class="bg-gray-50 rounded-xl p-3"><div class="text-[10px] text-gray-400">시장 평균</div><div class="font-bold">${aiCenterRate(kpi.average_rate)}</div></div>
            <div class="bg-blue-50 rounded-xl p-3"><div class="text-[10px] text-gray-400">최고금리</div><div class="font-bold text-blue-700">${aiCenterRate(kpi.max_rate ?? kpi.highest_rate)}</div></div>
            <div class="bg-gray-50 rounded-xl p-3"><div class="text-[10px] text-gray-400">우리금융</div><div class="font-bold">${aiCenterRate(woori.rate)}</div></div>
            <div class="bg-gray-50 rounded-xl p-3"><div class="text-[10px] text-gray-400">금리변동</div><div class="font-bold">${changes.change_count ?? kpi.change_count ?? 0}건</div></div>
          </div>
        </section>

        <section class="border border-gray-100 rounded-xl p-3">
          <div class="font-bold text-gray-800 mb-2">2. 시장 현황</div>
          <div>시장 최고금리는 <b>${top.bank ?? "-"}</b> ${aiCenterRate(top.rate)}, 시장 평균은 ${aiCenterRate(kpi.average_rate)}입니다.</div>
          <div class="mt-1">모니터링 상품수 ${Number(kpi.product_count || 0).toLocaleString()}개, 전일 변동 ${changes.change_count ?? kpi.change_count ?? 0}건입니다.</div>
        </section>

        <section class="border border-blue-100 bg-blue-50/50 rounded-xl p-3">
          <div class="font-bold text-blue-700 mb-2">3. 우리금융 경쟁력</div>
          <div>우리금융 금리 ${aiCenterRate(woori.rate)} · 시장순위 ${woori.market_rank ?? "-"}위 · 시장 평균 대비 ${aiCenterGap(woori.average_gap)}</div>
          <div class="mt-1">금융지주 저축은행 내 순위 ${woori.financial_rank ?? "-"}위입니다.</div>
        </section>

        <section class="border border-gray-100 rounded-xl p-3">
          <div class="font-bold text-gray-800 mb-2">4. 금융지주 저축은행 현황</div>
          <div>금융지주 선두는 <b>${financialTop.bank ?? "-"}</b> ${aiCenterRate(financialTop.rate)}입니다.</div>
          <div class="mt-2 space-y-1">
            ${financial.slice(0,6).map(item => `<div class="grid grid-cols-[30px_1fr_70px_70px] gap-2 bg-gray-50 rounded px-2 py-1.5"><span>${item.rank ?? "-"}</span><span>${item.bank ?? "-"}</span><span class="text-right">${aiCenterRate(item.rate)}</span><span class="text-right">${aiCenterChange(item.change)}</span></div>`).join("")}
          </div>
        </section>

        <section class="border border-gray-100 rounded-xl p-3">
          <div class="font-bold text-gray-800 mb-2">5. 금리 변동</div>
          <div>상승 ${upCount}건 · 하락 ${downCount}건 · 전체 변동 ${changes.change_count ?? 0}건</div>
          <div class="mt-1 text-gray-500">전일 대비 실제 금리 변경 기관을 기준으로 집계합니다.</div>
        </section>

        <section id="executive-report-ai-section" class="border border-indigo-100 bg-indigo-50/50 rounded-xl p-3">
          <div class="font-bold text-indigo-700 mb-2">6. AI 종합 판단</div>
          <div id="executive-report-ai-text" class="text-gray-500">AI 종합 판단을 생성하고 있습니다...</div>
        </section>
      </div>`;
}

async function openAIExecutiveReport(){
    const modal = document.getElementById("ai-report-modal");
    const content = document.getElementById("ai-report-content");

    if(!modal || !content) return;

    modal.classList.remove("hidden");
    modal.classList.add("flex");

    const dataBasis = formatDataBasis(window.sbDataBasisValue);
    const data = await loadAIAnalysisCenterData();

    // AI 응답과 무관하게 실제 API 데이터로 보고서 본문을 먼저 생성
    content.innerHTML = buildExecutiveReportBase(data, dataBasis);

    const basisEl = document.getElementById("ai-report-data-basis");
    if(basisEl) basisEl.textContent = `데이터 기준 ${dataBasis}`;

    const question =
        `데이터 기준 ${dataBasis}. 정기예금 시장과 금융지주 저축은행 경쟁현황을 임원 관점에서 종합 판단해줘. 시장 평균 ${data.kpi.average_rate ?? "-"}%, 최고금리 ${data.kpi.max_rate ?? data.kpi.highest_rate ?? "-"}%, 우리금융 금리 ${data.woori.rate ?? "-"}%, 시장순위 ${data.woori.market_rank ?? "-"}위, 금융지주 순위 ${data.woori.financial_rank ?? "-"}위, 전일 변동 ${data.changes.change_count ?? 0}건이다. 핵심 리스크, 우리금융 시사점, 대응 포인트를 간결하게 작성해줘.`;

    try{
        const response = await fetch("/api/ai/search", {
            method: "POST",
            headers: {"Content-Type":"application/json"},
            body: JSON.stringify({question})
        });

        if(!response.ok) throw new Error(`AI Report API Error : ${response.status}`);

        const result = await response.json();
        const answer = result?.answer || result?.result || result?.response || result?.message || "";
        const aiText = document.getElementById("executive-report-ai-text");

        if(aiText){
            aiText.textContent = answer || "AI 추가 판단이 없어 데이터 기반 보고서만 표시합니다.";
            aiText.className = answer ? "text-gray-700 whitespace-pre-wrap" : "text-gray-500";
        }
    }
    catch(error){
        console.error("AI REPORT ERROR:", error);
        const aiText = document.getElementById("executive-report-ai-text");
        if(aiText){
            aiText.textContent = "AI 추가 판단을 불러오지 못했습니다. 위 데이터 기반 보고서는 정상적으로 사용할 수 있습니다.";
            aiText.className = "text-gray-500";
        }
    }
}

function printExecutiveReport(){
    const report = document.getElementById("executive-report-document");
    if(!report) return;

    const popup = window.open("", "_blank", "width=900,height=1000");
    if(!popup) return;

    popup.document.write(`
      <!doctype html>
      <html lang="ko">
      <head>
        <meta charset="utf-8">
        <title>SBRateBot Executive Report</title>
        <script src="https://cdn.tailwindcss.com"><\/script>
        <style>
          body{font-family:Arial,"Noto Sans KR",sans-serif;padding:32px;color:#1f2937}
          @media print{body{padding:0}}
        </style>
      </head>
      <body>${report.outerHTML}</body>
      </html>
    `);
    popup.document.close();
    popup.focus();
    setTimeout(() => popup.print(), 700);
}

async function downloadExecutiveReportPDF(){
    const report = document.getElementById("executive-report-document");
    if(!report) return;

    const basis = formatDataBasis(window.sbDataBasisValue).replace(/[: ]/g, "-");
    const filename = `SBRateBot_Executive_Report_${basis}.pdf`;

    if(typeof html2pdf === "undefined"){
        alert("PDF 모듈을 불러오지 못했습니다. 출력 버튼에서 'PDF로 저장'을 선택해주세요.");
        printExecutiveReport();
        return;
    }

    const options = {
        margin: [8,8,8,8],
        filename,
        image: {type:"jpeg", quality:0.98},
        html2canvas: {scale:2, useCORS:true, backgroundColor:"#ffffff"},
        jsPDF: {unit:"mm", format:"a4", orientation:"portrait"},
        pagebreak: {mode:["avoid-all","css","legacy"]}
    };

    await html2pdf().set(options).from(report).save();
}


function closeAICenterDetail(){
    const modal = document.getElementById("ai-center-detail-modal");
    if(modal){
        modal.classList.add("hidden");
        modal.classList.remove("flex");
    }
}

function centerDetailFallback(tab, data){
    const {kpi, woori, rates, financial, changes} = data;

    if(tab === "financial"){
        const leader = financial[0] || {};
        const gapToLeader =
            Number.isFinite(Number(leader.rate)) &&
            Number.isFinite(Number(woori.rate))
                ? Number(woori.rate) - Number(leader.rate)
                : null;

        return `
          <div class="space-y-3">
            <div class="font-bold text-blue-700">금융지주 저축은행 심층 분석</div>
            <div class="grid grid-cols-3 gap-2 text-center">
              <div class="bg-gray-50 rounded-xl p-3"><div class="text-[10px] text-gray-400">우리금융 금리</div><div class="font-bold">${aiCenterRate(woori.rate)}</div></div>
              <div class="bg-gray-50 rounded-xl p-3"><div class="text-[10px] text-gray-400">금융지주 순위</div><div class="font-bold">${woori.financial_rank ?? "-"}위</div></div>
              <div class="bg-gray-50 rounded-xl p-3"><div class="text-[10px] text-gray-400">선두 대비</div><div class="font-bold">${gapToLeader === null ? "-" : aiCenterGap(gapToLeader)}</div></div>
            </div>
            <div class="bg-blue-50 border border-blue-100 rounded-xl p-3">
              우리금융의 금융지주 내 위치와 상위 금융지주 저축은행의 금리 조정 여부를 우선 확인합니다.
              시장 평균 대비 경쟁력은 ${aiCenterGap(woori.average_gap)} 입니다.
            </div>
          </div>`;
    }

    if(tab === "change"){
        const ups = Array.isArray(changes.up_top5) ? changes.up_top5 : [];
        const downs = Array.isArray(changes.down_top5) ? changes.down_top5 : [];
        return `
          <div class="space-y-3">
            <div class="font-bold text-blue-700">금리 변동 심층 분석</div>
            <div class="grid grid-cols-3 gap-2 text-center">
              <div class="bg-blue-50 rounded-xl p-3"><div class="text-[10px] text-gray-400">상승</div><div class="font-bold text-blue-600">${changes.up_count ?? ups.length}건</div></div>
              <div class="bg-red-50 rounded-xl p-3"><div class="text-[10px] text-gray-400">하락</div><div class="font-bold text-red-600">${changes.down_count ?? downs.length}건</div></div>
              <div class="bg-gray-50 rounded-xl p-3"><div class="text-[10px] text-gray-400">전체변동</div><div class="font-bold">${changes.change_count ?? 0}건</div></div>
            </div>
            <div class="bg-amber-50 border border-amber-100 rounded-xl p-3">
              전일 대비 실제 금리 변경 기관을 기준으로 방향성과 변동폭을 분석합니다.
              변동이 없는 날에는 상승·하락 목록이 비어 있는 것이 정상입니다.
            </div>
          </div>`;
    }

    return `
      <div class="space-y-3">
        <div class="font-bold text-blue-700">시장 심층 분석</div>
        <div class="grid grid-cols-3 gap-2 text-center">
          <div class="bg-gray-50 rounded-xl p-3"><div class="text-[10px] text-gray-400">시장 평균</div><div class="font-bold">${aiCenterRate(kpi.average_rate)}</div></div>
          <div class="bg-blue-50 rounded-xl p-3"><div class="text-[10px] text-gray-400">최고금리</div><div class="font-bold text-blue-700">${aiCenterRate(kpi.max_rate ?? kpi.highest_rate)}</div></div>
          <div class="bg-gray-50 rounded-xl p-3"><div class="text-[10px] text-gray-400">변동</div><div class="font-bold">${changes.change_count ?? kpi.change_count ?? 0}건</div></div>
        </div>
        <div class="bg-blue-50 border border-blue-100 rounded-xl p-3">
          상위권 금리 수준, 시장 평균, 금리 변동 건수를 함께 확인해 시장 경쟁 강도를 판단합니다.
          현재 TOP1은 ${rates[0]?.bank ?? "-"} ${aiCenterRate(rates[0]?.rate)} 입니다.
        </div>
      </div>`;
}

function centerDetailQuestion(tab, data){
    const {kpi, woori, financial, changes} = data;
    const basis = formatDataBasis(window.sbDataBasisValue);

    if(tab === "financial"){
        return `데이터 기준 ${basis}. 금융지주 저축은행만 대상으로 우리금융의 경쟁력을 심층 분석해줘. 우리금융 금리 ${woori.rate ?? "-"}%, 금융지주 순위 ${woori.financial_rank ?? "-"}위, 시장 평균 대비 ${woori.average_gap ?? 0}%p이며 금융지주 현황 데이터는 ${JSON.stringify(financial.slice(0,10))}이다. 상위사 대비 GAP, 경쟁사 금리 조정, 우리금융 대응 포인트 순으로 분석해줘. 일반적인 AI 질문 답변이 아니라 이 데이터에 근거한 분석만 작성해줘.`;
    }

    if(tab === "change"){
        return `데이터 기준 ${basis}. 오늘 저축은행 정기예금 금리 변동을 심층 분석해줘. 상승 ${changes.up_count ?? 0}건, 하락 ${changes.down_count ?? 0}건, 전체변동 ${changes.change_count ?? 0}건이며 상승 TOP5 ${JSON.stringify(changes.up_top5 || [])}, 하락 TOP5 ${JSON.stringify(changes.down_top5 || [])}이다. 변동 방향, 주요 기관, 우리금융에 미치는 시사점 순으로 작성해줘.`;
    }

    return `데이터 기준 ${basis}. 오늘 정기예금 시장을 심층 분석해줘. 시장 평균 ${kpi.average_rate ?? "-"}%, 최고금리 ${kpi.max_rate ?? kpi.highest_rate ?? "-"}%, 상품수 ${kpi.product_count ?? 0}개, 금리변동 ${changes.change_count ?? kpi.change_count ?? 0}건이다. 시장 수준, 상위권 경쟁 강도, 오늘의 체크포인트 순으로 데이터 기반 분석해줘.`;
}

async function openAICenterDetail(){
    const modal = document.getElementById("ai-center-detail-modal");
    const content = document.getElementById("ai-center-detail-content");
    const title = document.getElementById("ai-center-detail-title");
    const subtitle = document.getElementById("ai-center-detail-subtitle");

    if(!modal || !content) return;

    const tab = aiCenterActiveTab || "market";
    const titles = {
        market: "📊 시장분석 상세",
        financial: "🏦 금융지주 저축은행 상세",
        change: "📈 변동분석 상세"
    };

    if(title) title.textContent = titles[tab] || "📊 AI 상세 분석";
    if(subtitle) subtitle.textContent = "선택한 탭의 실제 데이터 기준 심층 분석";

    modal.classList.remove("hidden");
    modal.classList.add("flex");
    content.innerHTML = '<div class="py-10 text-center text-gray-400">실제 데이터를 불러와 심층 분석 중입니다...</div>';

    const data = await loadAIAnalysisCenterData();

    // API 장애가 있어도 데이터 기반 기본 분석은 반드시 표시
    content.innerHTML = centerDetailFallback(tab, data) +
        '<div id="ai-center-deep-ai" class="mt-4 border-t pt-4"><div class="text-gray-400">AI 심층 해석을 생성하고 있습니다...</div></div>';

    try{
        const response = await fetch("/api/ai/search", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({question: centerDetailQuestion(tab, data)})
        });

        if(!response.ok) throw new Error(`AI API Error : ${response.status}`);

        const result = await response.json();
        const answer = result?.answer || result?.result || result?.message || "";
        const aiBox = document.getElementById("ai-center-deep-ai");

        if(aiBox){
            aiBox.innerHTML = answer
                ? `<div class="font-bold text-blue-700 mb-2">🤖 AI 심층 해석</div><div class="bg-gray-50 border border-gray-100 rounded-xl p-3 whitespace-pre-wrap">${escapeReportHtml(answer)}</div>`
                : '<div class="text-gray-400">AI 추가 해석이 없어 기본 데이터 분석만 표시합니다.</div>';
        }
    }
    catch(error){
        console.error("AI CENTER DETAIL ERROR:", error);
        const aiBox = document.getElementById("ai-center-deep-ai");
        if(aiBox){
            aiBox.innerHTML = '<div class="text-gray-400">AI 추가 해석을 불러오지 못해 기본 데이터 분석만 표시합니다.</div>';
        }
    }
}

async function initAIAnalysisCenter(){
    const tabs = document.querySelectorAll("[data-ai-center-tab]");
    if(!tabs.length) return;

    tabs.forEach(button => {
        button.addEventListener("click", () => {
            aiCenterActiveTab = button.dataset.aiCenterTab || "market";
            updateAIAnalysisCenterTabs();
            renderAIAnalysisCenter(aiCenterActiveTab);
        });
    });

    const sideDetailBtn = document.getElementById("ai-side-detail-btn");
    if(sideDetailBtn){
        sideDetailBtn.addEventListener("click", openAICenterDetail);
    }

    const centerDetailClose = document.getElementById("ai-center-detail-close");
    if(centerDetailClose){
        centerDetailClose.addEventListener("click", closeAICenterDetail);
    }

    const centerDetailModal = document.getElementById("ai-center-detail-modal");
    if(centerDetailModal){
        centerDetailModal.addEventListener("click", e => {
            if(e.target === centerDetailModal){
                closeAICenterDetail();
            }
        });
    }

    const reportBtn = document.getElementById("ai-report-btn");
    if(reportBtn){
        reportBtn.addEventListener("click", openAIExecutiveReport);
    }

    const reportPrint = document.getElementById("ai-report-print");
    if(reportPrint){
        reportPrint.addEventListener("click", printExecutiveReport);
    }

    const reportPdf = document.getElementById("ai-report-pdf");
    if(reportPdf){
        reportPdf.addEventListener("click", downloadExecutiveReportPDF);
    }

    const reportClose = document.getElementById("ai-report-close");
    if(reportClose){
        reportClose.addEventListener("click", closeAIExecutiveReport);
    }

    const reportModal = document.getElementById("ai-report-modal");
    if(reportModal){
        reportModal.addEventListener("click", e => {
            if(e.target === reportModal){
                closeAIExecutiveReport();
            }
        });
    }

    await renderAIAnalysisCenter("market");
}

function updateAIAnalysisCenterTabs(){
    document.querySelectorAll("[data-ai-center-tab]").forEach(button => {
        const active = button.dataset.aiCenterTab === aiCenterActiveTab;
        button.className = active
            ? "ai-center-tab bg-white text-blue-700 shadow-sm rounded-md py-1.5 font-bold"
            : "ai-center-tab text-gray-500 rounded-md py-1.5 hover:text-blue-600";
    });
}

async function loadAIAnalysisCenterData(){
    const [kpi, woori, rates, financial, changes, ai] = await Promise.all([
        apiFetch("/api/kpi"), apiFetch("/api/woori"), apiFetch("/api/rates?all=1"),
        apiFetch("/api/financial"), apiFetch("/api/rate-changes"), apiFetch("/api/ai")
    ]);
    return {
        kpi:kpi || {}, woori:woori || {}, rates:Array.isArray(rates)?rates:[],
        financial:Array.isArray(financial)?financial:[], changes:changes || {}, ai:ai || {}
    };
}

async function renderAIAnalysisCenter(tab){
    const target = document.getElementById("ai-center-content");
    if(!target) return;
    target.innerHTML = '<div class="py-10 text-center text-gray-400">분석 데이터를 불러오는 중입니다.</div>';

    const data = await loadAIAnalysisCenterData();
    const {kpi,woori,rates,financial,changes} = data;

    if(tab === "financial"){
        const financialRank =
            woori.financial_rank ??
            financial.findIndex(item =>
                String(item.bank || "").includes("우리금융")
            ) + 1;

        target.innerHTML = `
        <div class="space-y-3">

          <!-- 기존 우리금융 경쟁력 미니패널 유지 -->
          <div class="bg-blue-50 border border-blue-100 rounded-xl p-3">
            <div class="flex items-center justify-between mb-2">
              <span class="font-bold text-blue-700">🏦 우리금융 경쟁력</span>
              <span class="text-[10px] text-gray-400">12개월 기준</span>
            </div>
            <div class="grid grid-cols-3 gap-2 text-center">
              <div class="bg-white rounded-lg py-2 border border-blue-50">
                <div class="text-[10px] text-gray-400">시장순위</div>
                <div class="font-bold text-blue-700 text-sm">${woori.market_rank ?? "-"}위</div>
              </div>
              <div class="bg-white rounded-lg py-2 border border-blue-50">
                <div class="text-[10px] text-gray-400">현재금리</div>
                <div class="font-bold text-gray-800 text-sm">${aiCenterRate(woori.rate)}</div>
              </div>
              <div class="bg-white rounded-lg py-2 border border-blue-50">
                <div class="text-[10px] text-gray-400">평균금리 대비</div>
                <div class="text-sm">${aiCenterGap(woori.average_gap)}</div>
              </div>
            </div>
          </div>

          <!-- 금융지주 저축은행 현황 -->
          <div class="border border-gray-100 rounded-xl p-3">
            <div class="flex items-center justify-between mb-3">
              <span class="font-bold text-gray-700">📋 금융지주 저축은행 현황</span>
              <span class="text-[10px] bg-blue-50 text-blue-700 px-2 py-1 rounded-full">우리금융 ${Number(financialRank) > 0 ? financialRank : "-"}위</span>
            </div>
            <div class="grid grid-cols-[34px_1fr_62px_70px] gap-2 px-2 pb-1 text-[10px] text-gray-400 text-center">
              <span>순위</span><span class="text-left">저축은행</span><span>금리</span><span>전일比</span>
            </div>
            <div class="space-y-1">
              ${financial.map(item=>{
                  const isWoori = String(item.bank || "").includes("우리금융");
                  return `<div class="grid grid-cols-[34px_1fr_62px_70px] gap-2 items-center rounded-lg px-2 py-1.5 ${isWoori ? "bg-blue-50 border border-blue-100 text-blue-700 font-bold" : "bg-gray-50"}">
                    <span class="text-center">${item.rank ?? "-"}</span>
                    <span class="truncate">${item.bank ?? "-"}</span>
                    <span class="font-bold text-center">${aiCenterRate(item.rate)}</span>
                    <span class="text-center">${aiCenterChange(item.change)}</span>
                  </div>`;
              }).join("") || '<div class="text-gray-400 text-center py-4">금융지주 저축은행 데이터 없음</div>'}
            </div>
          </div>

          <!-- 경쟁사 AI 분석을 금융지주 탭으로 통합 -->
          <div class="bg-indigo-50 border border-indigo-100 rounded-xl p-3 text-[11px] text-gray-600 leading-5">
            <div class="font-bold text-indigo-700 mb-1">🧠 AI 금융지주 저축은행 분석</div>
            금융지주 저축은행의 금리 순위와 전일 변동을 기준으로 우리금융의 경쟁 위치를 점검합니다.
            상위 금융지주 저축은행과의 금리 격차 및 경쟁사의 금리 조정 여부를 함께 모니터링합니다.
          </div>
        </div>`;
        return;
    }

    if(tab === "change"){
        const ups = Array.isArray(changes.up_top5)?changes.up_top5:[];
        const downs = Array.isArray(changes.down_top5)?changes.down_top5:[];
        target.innerHTML = `
        <div class="space-y-3">
          <div class="grid grid-cols-3 gap-2 text-center"><div class="bg-blue-50 rounded-lg p-2"><div class="text-[10px] text-gray-400">상승</div><div class="text-lg font-bold text-blue-600">${changes.up_count ?? ups.length}</div></div><div class="bg-red-50 rounded-lg p-2"><div class="text-[10px] text-gray-400">하락</div><div class="text-lg font-bold text-red-500">${changes.down_count ?? downs.length}</div></div><div class="bg-gray-50 rounded-lg p-2"><div class="text-[10px] text-gray-400">전체변동</div><div class="text-lg font-bold text-gray-700">${changes.change_count ?? 0}</div></div></div>
          <div class="grid grid-cols-2 gap-2"><div class="border border-blue-100 rounded-xl p-2.5"><div class="font-bold text-blue-600 mb-2">📈 상승 TOP5</div><div class="space-y-1">${ups.length?ups.map(item=>`<div class="flex justify-between bg-blue-50/50 rounded px-2 py-1.5"><span class="truncate mr-2">${item.bank ?? "-"}</span><span>${aiCenterChange(item.change)}</span></div>`).join(""):'<div class="text-gray-400 py-4 text-center">상승 없음</div>'}</div></div><div class="border border-red-100 rounded-xl p-2.5"><div class="font-bold text-red-500 mb-2">📉 하락 TOP5</div><div class="space-y-1">${downs.length?downs.map(item=>`<div class="flex justify-between bg-red-50/50 rounded px-2 py-1.5"><span class="truncate mr-2">${item.bank ?? "-"}</span><span>${aiCenterChange(item.change)}</span></div>`).join(""):'<div class="text-gray-400 py-4 text-center">하락 없음</div>'}</div></div></div>
          <div class="bg-amber-50 border border-amber-100 rounded-xl p-3 text-[11px] text-gray-600 leading-5"><div class="font-bold text-amber-800 mb-1">💡 변동 판단</div>전일 대비 실제 금리 변경 은행만 표시합니다. 변동이 없는 날에는 상승·하락 목록이 비어 있는 것이 정상입니다.</div>
        </div>`;
        return;
    }

    const summary = Array.isArray(data.ai.summary)?data.ai.summary:[];
    target.innerHTML = `
    <div class="space-y-3">
      <div class="grid grid-cols-2 gap-2 text-center"><div class="bg-gray-50 rounded-lg p-2"><div class="text-[10px] text-gray-400">시장 평균</div><div class="text-base font-bold">${aiCenterRate(kpi.average_rate)}</div></div><div class="bg-blue-50 rounded-lg p-2"><div class="text-[10px] text-gray-400">최고금리</div><div class="text-base font-bold text-blue-700">${aiCenterRate(kpi.max_rate ?? kpi.highest_rate)}</div></div><div class="bg-gray-50 rounded-lg p-2"><div class="text-[10px] text-gray-400">상품수</div><div class="text-base font-bold">${Number(kpi.product_count || 0).toLocaleString()}개</div></div><div class="bg-gray-50 rounded-lg p-2"><div class="text-[10px] text-gray-400">금리변동</div><div class="text-base font-bold">${changes.change_count ?? kpi.change_count ?? 0}건</div></div></div>
      <div class="border border-gray-100 rounded-xl p-3"><div class="font-bold text-gray-700 mb-2">🏆 시장 TOP5</div><div class="space-y-1.5">${rates.slice(0,5).map(item=>`<div class="flex justify-between bg-gray-50 rounded-lg px-2.5 py-2"><span>${item.rank ?? "-"}. ${item.bank ?? "-"}</span><span class="font-bold">${aiCenterRate(item.rate)}</span></div>`).join("") || '<div class="text-gray-400 text-center py-4">시장 데이터 없음</div>'}</div></div>
      <div class="bg-blue-50 border border-blue-100 rounded-xl p-3"><div class="font-bold text-blue-700 mb-1">🧠 AI 시장 요약</div><div class="text-[11px] text-gray-600 leading-5">${summary.slice(0,4).join("<br>") || "시장 데이터를 기준으로 금리 수준과 경쟁 강도를 모니터링하고 있습니다."}</div></div>
      <div class="bg-amber-50 border border-amber-100 rounded-xl p-3 text-[11px] text-gray-600 leading-5"><div class="font-bold text-amber-800 mb-1">🎯 오늘의 체크포인트</div>최고금리와 평균금리의 움직임, 상위권 경쟁사 조정, 우리금융 시장순위 변화를 함께 확인합니다.</div>
    </div>`;
}


/* ==========================================================
   Event Listener
========================================================== */


function setupEventListeners(){


    /* ======================================================
       TOP10 카테고리 변경
    ====================================================== */

    const category =
        document.getElementById(
            "top10-category-select"
        );


    if(category){

        category.addEventListener(
            "change",
            fetchRatesData
        );

    }



    /* ======================================================
       AI 질문
       현재 V5 index.html : #ai-question
    ====================================================== */

    const aiInput =
        document.getElementById(
            "ai-question"
        )
        ||
        document.getElementById(
            "ai-query-input"
        );


    if(aiInput){


        const inputRow =
            aiInput.parentElement;


        const searchButton =
            inputRow
            ?
            inputRow.querySelector(
                "button"
            )
            :
            null;


        if(searchButton){

            searchButton.addEventListener(
                "click",
                handleAISearch
            );

        }


        aiInput.addEventListener(
            "keydown",
            e => {

                if(e.key === "Enter"){

                    handleAISearch(e);

                }

            }
        );


        const questionPanel =
            aiInput.closest(
                ".bg-gray-50"
            );


        if(questionPanel){

            const quickButtons =
                questionPanel.querySelectorAll(
                    "button"
                );


            quickButtons.forEach(
                button => {

                    if(button === searchButton){

                        return;

                    }


                    button.addEventListener(
                        "click",
                        e => {

                            e.preventDefault();

                            const label =
                                button.textContent.trim();


                            const questionMap = {

                                "시장현황":
                                    "시장현황 알려줘",

                                "우리금융":
                                    "우리금융 경쟁력은",

                                "금융지주 저축은행":
                                    "금융지주 저축은행 현황 알려줘"

                            };


                            aiInput.value =
                                questionMap[label]
                                ||
                                label;


                            handleAISearch(e);

                        }
                    );

                }
            );

        }

    }



    /* ======================================================
       기존 FORM 방식도 호환
    ====================================================== */

    const aiForm =
        document.getElementById(
            "ai-search-form"
        );


    if(aiForm){

        aiForm.addEventListener(
            "submit",
            handleAISearch
        );

    }



    /* ======================================================
       상품 검색
    ====================================================== */

    setupProductSearch();


}




/* ==========================================================
   Dashboard Final Initialize
========================================================== */


window.addEventListener(
    "load",

    ()=>{
        startHeaderClock();
        refreshHeaderDataUpdateTime();
        setupHeaderRefresh();




        fetchAllProducts();



    }

);

/* ======================================================
   HERO 시장경쟁력 데이터 로딩
====================================================== */

async function loadHero(){

    try {

        const res = await fetch("/api/woori");

        const data = await res.json();


        // 시장순위

        const rank =
            document.getElementById("kpi-rank");


        if(rank){

            rank.innerHTML =
                `${data.market_rank || "-"}`;

        }



        // 우리금융 금리

        const wooriRate =
            document.getElementById("kpi-woori-rate-mini");


        if(wooriRate){

            wooriRate.innerText =
                data.rate
                ? `${Number(data.rate).toFixed(2)}%`
                : "-";

        }



        // 업권 최고금리

        const bestRate =
            document.getElementById("kpi-best-rate-mini");


        if(bestRate){

            const gap =
                Number(data.highest_gap || 0);


            const best =
                Number(data.rate || 0) - gap;


            bestRate.innerText =
                best
                ? `${best.toFixed(2)}%`
                : "-";

        }



                // 업권 최저금리

        const heroLowest =
            document.getElementById(
                "kpi-lowest-rate-mini"
            );


        if(heroLowest){

            const lowestRate =
                Number(
                    data.lowest_rate || 0
                );


            if(lowestRate > 0){

                heroLowest.innerText =
                    `${lowestRate.toFixed(2)}%`;

                heroLowest.className =
                    "text-sm font-bold";

            }


            else{

                heroLowest.innerText =
                    "-";

            }

        }



    }
    catch(error){

        console.error(
            "Hero 데이터 로딩 오류:",
            error
        );

    }

}


/* ==========================================================
   AI DETAIL MODAL + HOVER PREVIEW
========================================================== */


document.addEventListener(
    "click",
    function(e){


       /*
    상세 분석 버튼 클릭
*/


const btn =
    e.target.closest(
        "#ai-detail-btn"
    );


if(btn){


    console.log(
        "AI DETAIL BUTTON CLICK"
    );



    /*
        클릭 순간 우리금융 데이터 재조회
    */


    fetch(
        "/api/woori"
    )


    .then(
        response =>
            response.json()
    )


    .then(
        data => {


            console.log(
                "DETAIL WOORI DATA",
                data
            );



            /*
                상세분석 전용 데이터 저장
            */


            wooriPositionData =
                data;



            /*
                상세내용 다시 생성
            */


            if(
                typeof renderAIDetailModal === "function"
            ){


                renderAIDetailModal();


            }





            /*
                모달 열기
            */


            const modal =
                document.getElementById(
                    "ai-detail-modal"
                );



            if(modal){


                modal.classList.remove(
                    "hidden"
                );


                modal.classList.add(
                    "flex"
                );


            }


        }

    )


    .catch(
        error => {


            console.error(
                "WOORI DETAIL ERROR",
                error
            );


        }
    );


}




        /*
            모달 닫기
        */


        const close =
            e.target.closest(
                "#ai-detail-close"
            );



        if(close){


            const modal =
                document.getElementById(
                    "ai-detail-modal"
                );



            if(modal){


                modal.classList.add(
                    "hidden"
                );


                modal.classList.remove(
                    "flex"
                );


                console.log(
                    "AI DETAIL MODAL CLOSE"
                );


            }


        }


    }
);








/* ==========================================================
   AI DETAIL HOVER PREVIEW - 마지막 실제 질문/답변
========================================================== */

document.addEventListener(
    "mouseover",
    function(e){

        const btn = e.target.closest("#ai-detail-btn");
        if(!btn){
            return;
        }

        let preview = document.getElementById("ai-detail-preview");

        if(!preview){
            preview = document.createElement("div");
            preview.id = "ai-detail-preview";
            preview.className = `
                fixed z-[9999] w-96 bg-white border border-blue-100
                rounded-xl shadow-xl p-4 text-xs text-gray-700
            `;
            document.body.appendChild(preview);
        }

        const escapeHtml = value => String(value ?? "")
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");

        const question = window.sbLastAIQuestion ||
            document.getElementById("ai-question")?.value?.trim() ||
            "AI 질문";

        const answerHtml = window.sbLastAIAnswer ||
            "먼저 AI 질문을 실행하면 실제 답변 미리보기가 표시됩니다.";

        preview.innerHTML = `
            <div class="mb-3">
                <div class="font-bold text-blue-700">📊 AI 답변 미리보기</div>
            </div>
            <div class="text-[10px] text-gray-400 mb-1">질문</div>
            <div class="font-bold text-gray-800 mb-2">${escapeHtml(question)}</div>
            <div class="text-[10px] text-gray-400 mb-1">답변</div>
            <div class="text-[11px] leading-5 max-h-56 overflow-y-auto pr-1">${answerHtml}</div>
            <div class="mt-3 pt-2 border-t text-[10px] text-blue-600 text-right">클릭하면 전체 답변을 확인합니다 →</div>
        `;

        const rect = btn.getBoundingClientRect();
        const maxLeft = window.innerWidth - 400;
        preview.style.left = Math.max(12, Math.min(rect.left, maxLeft)) + "px";
        preview.style.top = (rect.bottom + 8) + "px";
        preview.style.display = "block";
    }
);


/* ==========================================================
   AI DETAIL HOVER OUT
========================================================== */


document.addEventListener(
    "mouseout",
    function(e){


        const btn =
            e.target.closest(
                "#ai-detail-btn"
            );



        if(!btn){

            return;

        }



        const preview =
            document.getElementById(
                "ai-detail-preview"
            );



        if(preview){


            preview.style.display =
                "none";


        }


    }
);

/* ==========================================================
   AI DETAIL CLICK TEST
========================================================== */

document.addEventListener(
    "click",
    function(e){

        const btn =
            e.target.closest(
                "#ai-detail-btn"
            );


        if(btn){

            console.log(
                "🔥 AI DETAIL CLICK TEST OK"
            );

        }

    }
);

/* ==========================================================
   시장분석 상세보기 : AI 질문 상세보기와 완전 분리
========================================================== */
document.addEventListener("click", function(event){
    if(event.target.closest("#market-detail-btn")){
        event.preventDefault();
        const modal = document.getElementById("market-detail-modal");
        if(modal){
            modal.classList.remove("hidden");
            modal.classList.add("flex");
        }
        return;
    }

    if(event.target.closest("#market-detail-close")){
        const modal = document.getElementById("market-detail-modal");
        if(modal){
            modal.classList.add("hidden");
            modal.classList.remove("flex");
        }
        return;
    }

    const modal = document.getElementById("market-detail-modal");
    if(modal && event.target === modal){
        modal.classList.add("hidden");
        modal.classList.remove("flex");
    }
});
