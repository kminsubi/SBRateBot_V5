﻿SBRateBot Dashboard v5.4 layout fix

반영:
1. AI 분석센터
- 시작점: HERO/좌측 메인 시작점과 동일
- 종료점: TOP10 + 최근공시 TOP5 + 우리금융比 상위 TOP5 종료점과 동일
- 좌측 main 실제 높이를 ResizeObserver로 읽어 자동 동기화
- 전체상품조회는 그 아래 별도 행 유지

2. TOP10 우리금융 행
- 내부 rounded-xl 강조 유지
- 저축은행/금리/공시일 컬럼 중심 재조정
- 공시일 우측까지 테두리 여유폭 확대

3. 상단 상품탭 / 하단 전체상품조회
- 기존 기능/ID/API 구조는 유지
- 상단 탭은 현재 구조를 유지하며 시각적 묶음 강화
- 전체상품조회는 기존 넓은 카드 구조 유지 (기능 손상 방지)

4. v5.3의 ISA/IRP AI 전용 backend(app.py) 수정 유지

교체 파일:
- index.html
- dashboard.js
- app.py
