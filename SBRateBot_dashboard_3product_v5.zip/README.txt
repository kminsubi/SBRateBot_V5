﻿SBRateBot 3상품 통합 대시보드 v5

- 정기예금 | ISA | 퇴직연금 탭
- 정기예금 기존 기능 유지
- ISA /api/isa?period=N
- 퇴직연금 /api/irp?period=N
- ISA/IRP KPI, TOP10, 우리금융 순위, 공시일 표시
- ISA/IRP 상승/하락 카드 → 최근 공시 TOP5 / 우리금융 대비 상위 TOP5
- 전체상품조회 전체 12컬럼 폭으로 이동
- AI 분석센터는 좌측 메인과 같은 첫 Grid Row에서 h-full로 정렬
- 전체상품조회는 아래 신규 행
- AI센터 ISA/IRP 모드 지원
- null 금리는 KPI/TOP 순위에서 제외
- 상승 파란 + / 하락 빨간 ▲ / 0 중립 / 전일比 유지
