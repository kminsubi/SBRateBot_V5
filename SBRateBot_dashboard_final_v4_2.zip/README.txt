﻿SBRateBot V5 Dashboard Final v4.2

이번 피드백 반영
1. AI 분석센터 상세분석 중복 모달 방지
   - AI센터 상세 버튼 클릭 시 일반 AI 답변 상세/시장 상세 강제 닫기
   - 이벤트 propagation 차단
   - AI센터 전용 모달만 표시

2. 임원보고서 시각 재설계
   - 우리금융 Blue 헤더
   - KPI 4개 요약
   - Executive Summary
   - 시장현황/우리금융 경쟁력 2단 구성
   - 금융지주 저축은행 현황 Compact Table
   - 금리변동 포인트
   - AI Executive View
   - 화면용 줄간격/여백 축소
   - 출력/PDF 기능 유지

3. 전체상품조회
   - 520px -> 400px로 조정
   - 과도하게 긴 패널 완화

4. AI 분석센터
   - min-height 500px 제거
   - 내용에 따라 자연 높이
   - 최대 610px 이후 내부 스크롤
   - 불필요한 하단 빈 공간 감소

5. 기존 기능 유지
   - 우리금융 경쟁력 미니패널
   - 금융지주 저축은행 현황
   - AI 금융지주 분석
   - 임원보고서 출력/PDF
   - 증감 표시 / 전일比
   - AI 질문 예시 placeholder
