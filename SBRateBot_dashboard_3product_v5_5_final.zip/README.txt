﻿SBRateBot v5.5 FINAL
- AI 분석센터: 강제 JS height 제거, 같은 Grid row stretch 방식
- 좌측 HERO~TOP10/TOP5와 우측 AI센터 동일 높이
- 전체상품조회는 다음 행 유지
- 우리금융 등장 시 ISA/IRP TOP10, 최근공시 TOP5, AI 금융지주현황, AI 변동/공시분석에 파란 rounded-xl 강조
- 퇴직연금 화면 표기: 퇴직연금(IRP)
- IRP 기준금리 표기 및 AI에 IRP/DC·IRP 약정금리 기준 명시
