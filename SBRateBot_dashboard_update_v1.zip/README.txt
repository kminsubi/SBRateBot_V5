﻿SBRateBot V5 Dashboard Update

교체 위치
- index.html -> templates/index.html
- dashboard.js -> static/js/dashboard.js

반영 내용
1. AI 분석센터 6탭 -> 4탭
   - 시장분석
   - 우리금융
   - 경쟁사
   - 변동분석
2. AI 분석센터 실제 API 연결
3. 전체 상품 조회 실제 /api/products 연결
4. 은행 / 기간 / 상품명 검색 필터 연결
5. 전체상품 테이블 추가
6. 상승/하락 TOP5 헤더 수정
   - 순위 | 저축은행 | 금리 | 전일대비
7. 기존 증감 표시 규칙 유지
   - 상승: 파란색 +
   - 하락: 빨간색 ▲
