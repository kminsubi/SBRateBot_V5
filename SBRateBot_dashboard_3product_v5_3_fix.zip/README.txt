﻿SBRateBot 3상품 대시보드 v5.3 수정본

가장 중요:
- AI 분석센터의 높이를 '시장 TOP10 + 최근공시TOP5/우리금융比상위TOP5' 행의 높이와
  ResizeObserver로 정확히 동기화.
- 더 이상 전체 좌측 메인 높이만큼 길어지지 않음.
- AI센터 하단과 우리금융比 상위 TOP5 패널 하단이 동일 위치.

ISA / 퇴직연금:
- AI 질문 요청에 category/period 전달.
- app.py에서 ISA/퇴직연금 전용 AI 분기 추가.
- Gemini가 선택된 상품의 실제 ISA/IRP JSON 데이터만 보고 답하도록 강제.
- 정기예금 데이터로 답하지 않도록 분리.
- AI센터 상세분석/임원보고서에도 category/period 전달.
- TOP10 / 최근공시TOP5 공시일 폰트 = 옆 데이터와 동일한 text-xs.
- TOP10 우리금융 행: table cell 테두리가 아니라 내부 rounded-xl wrapper 방식으로 변경.
  AI 분석센터와 유사한 둥근 테두리.
- 하나저축은행 퇴직연금 공시일:
  원본 irp_rates.json 자체가 disclosure_date=null / source=not_found 이므로
  날짜를 임의 생성하지 않고 '미확인' 표시.

주의:
- AI 질문 수정 때문에 이번 버전은 index.html + dashboard.js뿐 아니라 app.py도 교체해야 함.
